charging=`upower -i /org/freedesktop/UPower/devices/battery_BAT0 | grep 'state' | awk '{print $2}'`
value=`cat /sys/class/power_supply/BAT0/power_now`
#echo $charging
value=`echo "scale=2 ; $value / 1000000" | bc`
if [ "$charging" = "discharging" ];
then
    value=`echo "scale=2 ; $value * -1" | bc`
    #echo aaa $value
else
    value=" ${value}"
fi
echo "${value} W" #awk '{print $1*10^-6 " W"}' /sys/class/power_supply/BAT0/power_now

