math.randomseed(os.time()) --in seconds, so multiple runs in one second results in the same output
math.random(); math.random(); math.random();

local arrText={"THE END IS NEVER IS THE END IS NEVER IS THE END",--"THE END IS NEVER IS THE END IS NEVER IS THE END IS NEVER IS THE EN",
"0123456789ABCDEF",
"I HATE BASH",
"THIS IS SOME TEXT",
"LONG LIVE SQUARES",
"BASH",
"TTY",
"HI :D",
"FIGLET",
"COOL FONT",
"JS STOLE MY LUNCH MONEY",
"STANDING IS GOOD FOR YOU",
"FUNNY-CAT.GIF",
"WE DO A LITTLE BIT OF TROLLING",
"FUCK IT WE BALL",
"On the internet, nobody knows that you are a cat.",
"TO-DO: FIX LATER",
"#ASTRONAUT : PLEASE CRANK THE SILLY THING AROUND",
"PLEASE WORK!",
"KEEP IT SIMPLE STUPID",
"KISS",
"what now?",
"simplicity is the ultimate sophistication",
"GOOSE ON THE LOOSE",
"No balloon and no aeroplane will ever be practically successful - Lord Kelvin",
"Don't try to make it idiot proof. Someone's already working on a better idiot.",
"one test is worth a thousand expert opinions",
"By denying scientific priniciples, one may maintain any paradox",
"GO MAKE MISTAKES.",
"does my fat ass make my ass look fat?",
"ooooh colors",
"bill gates you are a fuck",
"Hacked by Chinese!",
"YOUR COMPUTER IS NOW STONED.",
"24 ROWS, 80 COLUMNS"}
--fortune cmd

--$'\n'

local sizeText=#arrText
local indexText=math.random(sizeText)--$(($RANDOM % $sizeText))
local text=arrText[indexText]

--text = "Hacked by Chinese!"
--text = "AAAAA$\'\\n\'BBB$\'\\n\'CC"

local arrEffects={"gay", "metal", "gay", "metal"} --"border"
--if text==THE END ... then border -> flip or 180, maybe flop

local sizeEffects=#arrEffects
local indexEffects=math.random(sizeEffects)--//$(($RANDOM % $sizeEffects))
local effect = arrEffects[indexEffects]

--font Term for default

--: # per line ; height - identifiers
--- is omitted if no identifiers
--: 8;4-n for example
--n: numbers only, l: letters only, f: fixed width
local arrFont={"Block:8;7",
"pagga:20;3",
--"pagga:20;3", --duplicate to make more likely
"smblock:25;4",
--"smblock:25;4", --duplicate to make more likely
"smbraille:39;2",
"future:25;3",
"3d:10;8",
"3D-ASCII:7;10",
"5lineoblique:8;7",
"Alligator:7;7",
"alligator3:8;7",
"ANSI\\ Regular:10;7",
"ANSI\\ Shadow:10;7",
"bigchief:8;8",
--"Bigfig:25;2",
"Big:11;8",
"Big\\ Money-ne:8;11",
"Chunky:9;5",
"Colossal:7;11-n", --only n because I dont really like the letters
"Cricket:9;8",
"Delta\\ Corps\\ Priest\\ 1:6;7-l",
"Electronic:6;12",
"LCD:13;6",
"Lean:8;8",
"rebel:7;11",
"Reverse:8;11",
"Rozzo:8;7",
"Tubes-Smushed:14;7",
"Slant:11;6",

"terminus_dots:20;3",
"smslant:18;3",

"Term:80;1" --last resort basically
}

function Shuffle(tbl)
  for i = #tbl, 2, -1 do
    local j = math.random(i)
    tbl[i], tbl[j] = tbl[j], tbl[i]
  end
  return tbl
end

arrFont = Shuffle(arrFont) --lets us lazily cycle through fonts for size restrictions without compromising truly random selection
--kind of a shit system but its fine

--local font="smblock"
local sizeArrFont=#arrFont
local indexFont=math.random(sizeArrFont)--$(($RANDOM % $sizeArrFont))
local font=arrFont[indexFont]

--very simple algorithm
function SizeOfFont(inputText, inputFont)
    local colonIndex,_ = string.find(inputFont, ":")
    local semicolonIndex,_ = string.find(inputFont, ";")
    local dashIndex = nil
    if colonIndex then
        dashIndex,_ = string.find(string.sub(inputFont, colonIndex, #inputFont), "-") 
    end
    if dashIndex then dashIndex = dashIndex + colonIndex - 1 end
    local numCharPerLine = tonumber(string.sub(inputFont, colonIndex + 1, semicolonIndex - 1))
    local height = tonumber(string.sub(inputFont, semicolonIndex + 1, #inputFont))
    --print(inputFont)
    if dashIndex then
        height = tonumber(string.sub(inputFont, semicolonIndex + 1, dashIndex - 1))
    else
        height = tonumber(string.sub(inputFont, semicolonIndex + 1, #inputFont))
    end

    --print(tonumber(string.sub(inputFont, semicolonIndex + 1, #inputFont)))
    --print(height)

    --[[local num = #inputText;
    print(inputText)
    local _, numNewLines = string.gsub("$\'\\n\'", "$\'\\n\'", "");
    if numNewLines > 0 then
        --local indexLast = string.find(inputText, "$\'\\n\'");
        local indexLast = inputText:match(".*()A")
        print(indexLast);
    end--]]

    local size = (#inputText / numCharPerLine) * height
    --print(inputFont .. " " .. size)
    return size
end

for i = 0, #arrFont - 1, 1 do
    local size = SizeOfFont(text, arrFont[1 + ((i + indexFont - 1) % #arrFont)])
    if size <= 10 and size >= 2 then --not entirely accurate, can easily go above 10 lines height
        font = arrFont[1 + ((i + indexFont - 1) % #arrFont)]
        break
    end
    if i == #arrFont - 1 then
        print("ABCDE")
    end
end

if text == "THE END IS NEVER IS THE END IS NEVER IS THE END" then
    --maybe create algorithm for repetition
    --make sure that it perfectly fits
    font="terminus_dots"
else
    --print(font)
    local start,_ = string.find(font, ":")

    font = string.sub(font, 0, start - 1)
end

-- | tr ' _/' '/ '

--local command = "figlet -t -k -F " .. effect .. " -F crop " .. "-f " .. font .. " \"" .. text .. "\""
local command = "figlet -t -k -p -f" .. font .. " \"" .. text .. "\""
if math.random() < 1 then --will disregard -F effect if passes, honestly just fuck it.
    if math.random() < 0.6 then
        local arrEffects2 = {"cividis", "cool", "cubehelix", "fruits", "lolcat", "plasma", "rainbow", "rd-yl-gn", "sinebow", "spectral", "turbo", "viridis", "warm"}
        local effect2 = arrEffects2[math.random(#arrEffects2)]
        --command = command .. " | ~/scripts/lolcrab --spread " .. (10 + math.random() * 70)
        command = command .. " | ~/scripts/lolcrab -g " .. effect2
    else
        command = command .. " | ~/scripts/lolcrab --random-colors " .. math.random(2, 7)
    end

    if math.random() < 0.4 then
        command = command .. " --sharp " .. math.random(10, 40)
    end

    --[[if math.random() < 1 then
        command = command .. " --scale " .. 0.01 + math.random() * 0.12
    end--]]

    --this just looks like shit.
    --[[if math.random() < 0.1 then
        command = command .. " --invert"
    end--]] 
end
os.execute(command)