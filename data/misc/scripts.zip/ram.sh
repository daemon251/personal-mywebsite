value="$(free | grep Mem | awk '{print $3}')"
value=`echo "scale=2 ; $value / 1048576" | bc`
ramMax="$(free | grep Mem | awk '{print $2}')"
ramMax=`echo "scale=2 ; $ramMax / 1048576" | bc`
percent=`echo "scale=0; $value * 100 / $ramMax" | bc`
echo ${value}GiB / ${ramMax}GiB - ${percent}%
