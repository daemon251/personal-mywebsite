#unused I use the lua now

arrText=("THE END IS NEVER IS THE END IS NEVER IS THE END IS NEVER IS THE EN" 
"0123456789ABCDEF"
"I HATE BASH"
"THIS IS SOME TEXT"
"LONG LIVE SQUARES"
"HI THERE :D"
"JS STOLE MY LUNCH MONEY"
"STANDING IS GOOD FOR YOU"
"FUNNY-CAT.GIF"
"WE DO A LITTLE BIT OF TROLLING"
"FUCK IT WE BALL"
"On the internet, nobody knows that you are a cat."
"TO-DO: FIX LATER"
"#ASTRONAUT : PLEASE CRANK THE SILLY THING AROUND"
"PLEASE WORK!"
"KEEP IT SIMPLE STUPID"
"what now?"
"simplicity is the ultimate sophistication"
"GOOSE ON THE LOOSE"
"No balloon and no aeroplane will ever be practically successful - Lord Kelvin"
"Don''t try to make it idiot proof. Someone's already working on a better idiot."
"one test is worth a thousand expert opinions"
"By denying scientific priniciples, one may maintain any paradox"
"GO MAKE MISTAKES."
"does my fat ass make my ass look fat?"
"25 ROWS, 40 COLUMNS")

sizeText=${#arrText[@]}
indexText=$(($RANDOM % $sizeText))
text=${arrText[$indexText]}
textSize=${#text} 

arrEffects=("gay" "metal" "gay" "metal") #"border"
#if text==THE END ... then border -> flip or 180, maybe flop

sizeEffects=${#arrEffects[@]}
indexEffects=$(($RANDOM % $sizeEffects))

#font Term for default

#: # per line ; height - identifiers
#- is omitted if no identifiers
#: 8;4-n for example
#n: numbers only, l: letters only, f: fixed width
arrFont=("Block:8;7"
"pagga:20;3"
"smblock:25;4"
"smbraille:39;2"
"future:25;2"
"3d:10;8"
"3D-ASCII:7;10"
"5lineoblique:8;7"
"Alligator:7;7"
"alligator3:8;7"
"ANSI\ Regular:10;7"
"ANSI\ Shadow:10;7"
"bigchief:8;8"
"Bigfig:25;2"
"Big:11;8"
"Big\ Money-ne:8;11"
"Chunky:9;5"
"Colossal:7;11-n" #only n because I dont really like the letters
"Cricket:9;8"
"Delta\ Corps\ Priest\ 1:6;9-l"
"Electronic:6;12"
"LCD:13;6"
"Lean:8;8"
"rebel:7;11"
"Reverse:8;11"
"Rozzo:8;7"
"Tubes-Smushed:14;7"
"Slant:11;6"
)

font="smblock"
sizeArrFont=${#arrFont[@]}
indexFont=$(($RANDOM % $sizeArrFont))
font=${arrFont[$indexFont]}

if [ "$text" == "THE END IS NEVER IS THE END IS NEVER IS THE END IS NEVER IS THE EN" ]; 
then
    font="smblock"
elif [ $textSize -lt 20 ]; then
    echo "a"
elif [ $textSize -lt 40 ]; then
    echo "b"
else
    echo "c"
fi

#lolcat
figlet -t -k -F ${arrEffects[$indexEffects]} -f ${font} ${text} -F crop
