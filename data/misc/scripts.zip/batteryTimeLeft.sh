charging=`upower -i /org/freedesktop/UPower/devices/battery_BAT0 | grep 'state' | awk '{print $2}'`
value=0
if [ "$charging" = "discharging" ];
then
    value=`upower -i /org/freedesktop/UPower/devices/battery_BAT0 | grep 'time to empty:' | awk '{print $4 " " $5}'`
else
    value=`upower -i /org/freedesktop/UPower/devices/battery_BAT0 | grep 'time to full:' | awk '{print $4 " " $5}'`
fi
echo $value 
