xfce4-terminal -e "bash -c 'while true; do sleep 0.1; clear; chafa --speed 5 -O 9 *.gif; done; read'"
