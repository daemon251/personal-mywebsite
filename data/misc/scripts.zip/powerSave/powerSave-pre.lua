math.randomseed(os.time()) --in seconds
math.random(); math.random(); math.random();

--[[function os.capture(cmd, raw)
  local f = assert(io.popen(cmd, 'r'))
  local s = assert(f:read('*a'))
  f:close()
  if raw then return s end
  s = string.gsub(s, '^%s+', '')
  s = string.gsub(s, '%s+$', '')
  s = string.gsub(s, '[\n\r]+', ' ')
  return s
end--]]

function exec(cmd)
    local handle = io.popen(cmd)
    local output = handle:read('*a')
    local outputf = output:gsub('[\n\r]', ' ')
    handle:close()
    return outputf
end

dataTable = {}
function addToDataTable(data)
    dataTable[#dataTable + 1] = data
end

addToDataTable(exec('prime-select query'))
addToDataTable(exec("cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor"))

file = io.open("test.txt", "w")
--file:write("Hello World")
--file:write("aaa")
for i = 1, #dataTable+1, 1
do
  local data = dataTable[i]
  if(data ~= nil)
  then
      --print(dataTable[i])
      file:write(dataTable[i] .. "\n")
  end
end
file:close()




-----------------------------
-- START ACTUALLY DOING IT --
-----------------------------

--because I have a processor with P and E cores that are not automatically prioritized properly
function toggleP_Cores(enable)

end

print("Selecting Intel iGPU...\n")
os.execute('sudo -k prime-select intel')
print("\nSelecting cpu governer to powersave...\n")
os.execute('sudo -S cpufreq-set -r -g powersave')
print("Done")
